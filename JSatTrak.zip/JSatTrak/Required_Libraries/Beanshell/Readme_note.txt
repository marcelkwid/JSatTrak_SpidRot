// NOTE: in beanshell jar (i.e. bsh-2.0b4.jar) need to replace desktop.bsh, with one included with this source -- it allows bean shell desktop to be reopened
- Shawn Gano, April 2008